AWS IAM User Creation Automation - Linux terminal
